#include <iostream>
#include <algorithm>
#include <bitset>
#include <string.h>

using namespace std;

const int DIV = 1000000007;

int M;
string E;
string T;
int dp[1<<14][20][2];

int solve(bitset<15> bit, int Remain, bool bEqual)
{
	int& ret = dp[bit.to_ulong()][Remain][bEqual];
	if (ret != -1) return ret;

	int n = bit.count();
	if (n >= E.size())
		return !bEqual && (Remain == 0);

	ret = 0;
	for (int i = 0; i < E.size(); i++)
	{
		if (bit[i]) continue;
		if (bEqual && T[n] < E[i]) continue;

		if (i == 0 || E[i - 1] != E[i] || bit[i - 1])
		{
			auto bNewEqual = bEqual && (T[n] == E[i]);
			auto newBit = bit;
			newBit[i] = true;
			auto newRemain = (Remain*10+(E[i]-'0'))%M;
			ret += solve(newBit, newRemain, bNewEqual);
			ret %= DIV;
		}
	}

	return ret;
}

int main()
{
	int C;
	cin >> C;
	while (C--)
	{
		cin >> T >> M;

		E = T;
		sort(E.begin(), E.end());
		memset(&dp, -1, sizeof(dp));

		bitset<15> b;
		
		cout << solve(b, 0, true) << endl;
	}
	return 0;
}

